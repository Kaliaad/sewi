<?php
        header("Location: https://letoa.me");
        exit();
?>